cd ReactJS/
rm -rf ./test-report.xml && CI=true npm test


